from flask import Flask, request, jsonify
from youtube_transcript_api import YouTubeTranscriptApi
from flask_cors import CORS
import json
import os

app = Flask(__name__)
CORS(app)

def create_semantic_map(text):
    # Placeholder: insert your semantic mapping logic here
    return text

def save_transcript_to_file(video_id, transcript_data):
    """Save transcript data to both .txt and .json files"""
    try:
        os.makedirs('transcripts', exist_ok=True)

        # Save .txt file
        txt_path = os.path.join('transcripts', f"{video_id}.txt")
        with open(txt_path, 'w', encoding='utf-8') as f:
            f.write(f"Transcript for YouTube video: {video_id}\n")
            f.write("-" * 50 + "\n\n")
            for segment in transcript_data:
                start = segment['start']
                end = start + segment['duration']
                text = segment['text']
                f.write(f"[{start:.1f}s - {end:.1f}s] {text}\n")

        # Save .json file
        json_path = os.path.join('transcripts', f"{video_id}.json")
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(transcript_data, f, ensure_ascii=False, indent=2)

        print(f"Transcript saved to {txt_path} and {json_path}")
        return True
    except Exception as e:
        print(f"Error saving transcript: {e}")
        return False

@app.route('/api/transcript', methods=['POST'])
def get_transcript():
    data = request.json
    video_id = data.get("id")
    if not video_id:
        return jsonify({"error": "YouTube video ID missing"}), 400

    try:
        print(f"Fetching transcript for video ID: {video_id}")
        ytt_api = YouTubeTranscriptApi()
        transcript_list = ytt_api.list(video_id)
        transcript = transcript_list.find_transcript(['en', 'ml', 'ta', 'hi']).fetch()

        # Convert to raw dicts
        transcript_data = transcript.to_raw_data()

        # Apply semantic mapping
        for segment in transcript_data:
            segment['text'] = create_semantic_map(segment['text'])

        # Save to file
        save_transcript_to_file(video_id, transcript_data)

        print(f"Successfully processed transcript with {len(transcript_data)} segments")
        return jsonify(transcript_data)
    except Exception as e:
        error_msg = str(e)
        print(f"Error fetching transcript: {error_msg}")
        return jsonify({"error": error_msg}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({"status": "ok", "message": "API is running"}), 200

if __name__ == '__main__':
    print("Starting YouTube Transcript API Server...")
    app.run(debug=True)